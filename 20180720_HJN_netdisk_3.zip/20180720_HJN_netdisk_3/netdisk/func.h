#ifndef FUNC_H
#define FUNC_H

#include "head.h"
#include "que.h"

#define COMMAND_NUM 7
#define     READ_MAX_SIZE   1024
#define     MD5_SIZE        16
#define     MD5_STR_LEN     (MD5_SIZE * 2)
#define BUF_SIZE 1024
#define PAGE_SIZE 4096

typedef void* (*thread_func_t)(void*p);

typedef struct{
    pthread_t *pth_id;			//Start address of thread id
    int pthread_num;			//num of created threads
    que_t que;
    thread_func_t threadfunc;	//the function of thread
    pthread_cond_t cond;        //queue lock condition
    short start_flag;			//if thread is starting
}factory,*pfac;

typedef struct{
    int len;
    char buf[BUF_SIZE];
}train;


int f_init(pfac,thread_func_t,int,int);
int f_start(pfac);
int tcp_init(const char*,int,int);

int get_md5(const char *filename, char *md5_str);
int makedir(MYSQL* conn,char *dir,int code,int uid);
int cd(MYSQL*conn,char* dir,int* code,int uid);
int ls(MYSQL*conn,int code,int uid,char *usrname,int sfd);
int gets_cd(int mode,MYSQL*conn,char *file_name,int code,int uid,int sfd);
int puts_cd(MYSQL*conn,int code,int uid,int sfd);
int rm(MYSQL*conn,char *file_name,int code,int uid);

int excute_Command(MYSQL*,int,int,char*,int*,int,char*);
int connect_mysql(MYSQL*);
int log_mysql(MYSQL*conn,const char* op,int uid,char* result);
int get_Salt(MYSQL*,char*,char*);
int get_Pwdp(MYSQL*,char*,char*);

int send_file(int,const char*,off_t);
int send_n(int,char*,int);
int recv_n(int,char*,int);
int recv_file(int,char*,off_t*,char*);

#endif // FUNC_H
