#include "func.h"

int exit_fds[2];
MYSQL* conn;

void* thread_func(void* p);
void sig_exit_func(int signum);
void no_block_stat(int fd);

int main()
{
    FILE* config_file;
    config_file=fopen("configure","rb");
    check_error(NULL,config_file,"fopen");

    char ip[16]={0};
    int port;
    int thread_num;
    int capacity;

    fscanf(config_file,"%s %d%d%d",ip,&port,&thread_num,&capacity);

    factory f;
    f_init(&f,thread_func,thread_num,capacity);
    f_start(&f);

    int sfd;
    sfd=tcp_init(ip,port,capacity);

    pipe(exit_fds);

    //连接数据库
    conn=mysql_init(NULL);
    connect_mysql(conn);

    int new_fd;
    pque_t p=&f.que;
    pnode_t pnew;

    int ret;
    int epfd=epoll_create(1);
    struct epoll_event event,evs[3];
    event.events=EPOLLIN;
    event.data.fd=sfd;
    ret=epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
    check_error(-1,ret,"epoll_ctl");
    event.data.fd=exit_fds[0];
    ret=epoll_ctl(epfd,EPOLL_CTL_ADD,exit_fds[0],&event);
    check_error(-1,ret,"epoll_ctl");

    signal(SIGINT,sig_exit_func);

    while(1)
    {
        ret=epoll_wait(epfd,evs,3,-1);
        for(int i=0;i<ret;i++)
        {
            if(sfd==evs[i].data.fd)
            {
                new_fd=accept(sfd,NULL,NULL);
                pnew=(pnode_t)calloc(1,sizeof(node_t));
                pnew->new_fd=new_fd;
                pnew->code=0;
                pnew->command_id=0;
                bzero(pnew->usrname,sizeof(pnew->usrname));
                bzero(pnew->arg_cd,sizeof(pnew->arg_cd));
                pthread_mutex_lock(&p->que_mutex);
                que_insert(p,pnew);
                pthread_mutex_unlock(&p->que_mutex);
                pthread_cond_signal(&f.cond);
            }
            if(exit_fds[0]==evs[i].data.fd)
            {
                close(sfd);
                pnew=(pnode_t)calloc(1,sizeof(node_t));
                pnew->new_fd=-1;
                pthread_mutex_lock(&p->que_mutex);
                que_insert_exit(p,pnew);
                pthread_mutex_unlock(&p->que_mutex);
                pthread_cond_broadcast(&f.cond);
                for(i=0;i<f.pthread_num;i++)
                {
                    pthread_join(f.pth_id[i],NULL);
                }
                mysql_close(conn);
                exit(0);
            }
        }
    }
    close(sfd);
    mysql_close(conn);
    return 0;
}

void* thread_func(void* p)
{
    pfac pf=(pfac)p;
    pque_t pq=&pf->que;
    pnode_t pcur;
    int login_flag=1;

    while(1)
    {
        pthread_mutex_lock(&pq->que_mutex);
        if(0==pq->size)
        {
            pthread_cond_wait(&pf->cond,&pq->que_mutex);
        }
        que_get(pq,&pcur);
        pthread_mutex_unlock(&pq->que_mutex);
        if(pcur!=NULL)
        {
            //由子进程监控对应客户端的命令请求
            int ret;
            int iret;
            int epfd=epoll_create(1);
            struct epoll_event event,evs[1];

            no_block_stat(pcur->new_fd);
            event.events=EPOLLIN|EPOLLET;
            event.data.fd=pcur->new_fd;
            ret=epoll_ctl(epfd,EPOLL_CTL_ADD,pcur->new_fd,&event);
            check_error_void(-1,ret,"epoll_ctl");

            int len;
            int command_id;
            char arg_cd[128]={0};
            while(1)
            {
                ret=epoll_wait(epfd,evs,1,-1);
                for(int i=0;i<ret;i++)
                {
                    if(evs[i].data.fd==pcur->new_fd)
                    {
                        if(login_flag)  //刚登录时
                        {
                            int iret;
                            char usrname[16]={0};
                            char salt[16]={0};
                            char pwdp[512]={0};
                            char client_pwdp[512]={0};
                            int uid=0;
                            //接受客户端发送的用户名
                            while(1)
                            {
                                iret=recv(pcur->new_fd,usrname,sizeof(usrname)-1,0);
                                //发送用户名对应的salt给客户端
                                if(iret>0)
                                {
                                    uid=get_Salt(conn,usrname,salt);
                                    if(uid<=0)
                                    {
                                        strcpy(salt,"fail");
                                        log_mysql(conn,"login",pcur->uid,"failed");
                                    }
                                    send(pcur->new_fd,salt,strlen(salt),0);
                                    break;
                                }
                            }
                            //账户名正确，则接受客户端发送的密文
                            while(uid)
                            {
                                iret=recv(pcur->new_fd,client_pwdp,sizeof(client_pwdp)-1,0);
                                if(iret>0)
                                {
                                    get_Pwdp(conn,usrname,pwdp);
                                    iret=strcmp(pwdp,client_pwdp);
                                    int flag=0;
                                    //匹配成功
                                    if(iret==0)
                                    {
                                        pcur->uid=uid;
                                        strcpy(pcur->usrname,usrname);
                                        flag=1;
                                        login_flag=0;
                                        log_mysql(conn,"login",pcur->uid,"success");
                                    }
                                    else
                                    {
                                        log_mysql(conn,"login",pcur->uid,"failed");
                                    }
                                    //把匹配结果发送给客户端
                                    send(pcur->new_fd,&flag,sizeof(flag),0);
                                    uid=0;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            bzero(arg_cd,sizeof(arg_cd));
                            //接受命令长度
                            iret=recv_n(pcur->new_fd,(char*)&len,4);
                            if(iret!=0)
                                goto next;
                            //接受命令编号
                            iret=recv_n(pcur->new_fd,(char*)&command_id,4);
                            if(iret==0)
                                pcur->command_id=command_id;
                            else
                                goto next;
                            //接受命令参数
                            iret=recv_n(pcur->new_fd,arg_cd,len);
                            if(iret==0)
                            {
                                bzero(pcur->arg_cd,sizeof(pcur->arg_cd));
                                strcpy(pcur->arg_cd,arg_cd);
                                excute_Command(conn,pcur->new_fd,pcur->command_id,pcur->arg_cd,&pcur->code,pcur->uid,pcur->usrname);
                                break;
                            }
next:
                            if(-1==iret)
                            {
                                char op[32]="client disconnect";
                                char result[5]={0};
                                sprintf(result,"%ld",pcur->new_fd);
                                log_mysql(conn,op,pcur->uid,result);
                                event.data.fd=pcur->new_fd;
                                epoll_ctl(epfd,EPOLL_CTL_DEL,pcur->new_fd,&event);
                                close(pcur->new_fd);
                                free(pcur);
                                pthread_exit(NULL);
                            }
                            else
                            {
                                char op[32]="client disconnect";
                                char result[5]={0};
                                sprintf(result,"%ld",pcur->new_fd);
                                log_mysql(conn,op,pcur->uid,result);
                                pthread_exit(NULL);
                            }
                        }
                    }
                }
            }
        }
    }
}

void sig_exit_func(int signum)
{
    char flag=1;
    write(exit_fds[1],&flag,1);
}

void no_block_stat(int fd)
{
    int status=fcntl(fd,F_GETFL);
    status=status|O_NONBLOCK;
    fcntl(fd,F_SETFL,status);
}
