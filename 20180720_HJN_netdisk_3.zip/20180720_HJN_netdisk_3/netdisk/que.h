#ifndef QUE_H
#define QUE_H

#include"head.h"

//Child thread queue linked list node structure
typedef struct tag_node{
    int new_fd;
    struct tag_node* pNext;
    char arg_cd[128];
    int command_id;
    int uid;
    int code;   //目录
    char usrname[32];
}node_t,*pnode_t;

//Child thread linked list
typedef struct{
    pnode_t que_head,que_tail;
    int que_capacity;			//limited length
    int size;					//the num of child threads
    pthread_mutex_t que_mutex;	//Queue lock
}que_t,*pque_t;

void que_insert(pque_t,pnode_t);
void que_get(pque_t,pnode_t*);
void que_insert_exit(pque_t,pnode_t);

#endif // QUE_H
