56 path=20180720_华建楠_netdisk_3/netdisk/tran_n.cpp
27 mtime=1532011066.535595
27 atime=1532068620.098785
