#include"func.h"

int recv_file(int sfd,char* file_name_arg,off_t* file_size_arg,char* md5)
{
    int ret;

    int len;
    char buf[PAGE_SIZE]={0};

    char file_name[32]={0};
    off_t file_size=0;

    //接文件名
    while(1)
    {
        if(recv_n(sfd,(char*)&len,4)==0)
            break;
    }
    recv_n(sfd,file_name,len);
    strcpy(file_name_arg,file_name);

    //接文件大小
    double down_load_size=0;
    while(1)
    {
        if(recv_n(sfd,(char*)&len,4)==0)
            break;
    }
    recv_n(sfd,(char*)&file_size,len);
    *file_size_arg=file_size;

    //按秒打印下载百分比
    int fd=open(md5,O_RDWR|O_CREAT,0666);
    check_error(-1,fd,"open");
    ftruncate(fd,file_size);
    time_t start,end;
    start=time(NULL);
    end=time(NULL);

    if(file_size>=100000000)
    {
        len=PAGE_SIZE;
        void* p;
        off_t offset=0;
        while(1)
        {
            ret=recv_n(sfd,buf,len);
            if(ret<0)
            {
                if(down_load_size<file_size)
                {
                    len=file_size-down_load_size;
                    if(len<PAGE_SIZE)
                    {
                        p=mmap(NULL,len,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_SHARED,fd,offset);
                        if(p==MAP_FAILED)
                        {
                            printf("down percent %5.2f%s\n",down_load_size/(file_size)*100,"%");
                            perror("mmap");
                            return -1;
                        }
                        memcpy(p,buf,len);
                        down_load_size=down_load_size+len;
                    }
                    else
                    {
                        return -1;
                    }

                }
                printf("down percent %5.2f%s\n",down_load_size/(file_size)*100,"%");
                munmap(p,len);
                break;
            }
            p=mmap(NULL,len,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_SHARED,fd,offset);
            if(p==MAP_FAILED)
            {
                printf("down percent %5.2f%s\n",down_load_size/(file_size)*100,"%");
                perror("mmap");
                return -1;
            }
            memcpy(p,buf,len);
            offset+=len;
            down_load_size=down_load_size+len;
            munmap(p,len);
            end=time(NULL);
            if(end-start>=1)
            {
                printf("down percent %5.2f%s\r",down_load_size/(file_size)*100,"%");
                fflush(stdout);
                start=end;
            }
        }
    }
    else
    {
        while(1)
        {
            ret=recv_n(sfd,(char*)&len,4);
            if(ret==0&&len>0)
            {
                ret=recv_n(sfd,buf,len);
                if(ret<0)
                {
                    printf("down percent %5.2f%s\n",down_load_size/(file_size)*100,"%");
                    return -1;
                }
                write(fd,buf,len);
                down_load_size=down_load_size+len;
                end=time(NULL);
                if(end-start>=1)
                {
                    printf("down percent %5.2f%s\r",down_load_size/(file_size)*100,"%");
                    fflush(stdout);
                    start=end;
                }
            }else if(len==0){
                printf("down percent %5.2f%s\n",down_load_size/(file_size)*100,"%");
                break;
            }
        }
    }

    close(fd);
    return 0;
}
