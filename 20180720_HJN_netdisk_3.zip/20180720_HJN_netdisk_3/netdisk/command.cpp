#include"func.h"

off_t get_offset(char* file_name,char* arg_cd)
{
    off_t offset=0;
    int i=0;
    int len=strlen(arg_cd);
    while(arg_cd[i]!=' ')
    {
        file_name[i]=arg_cd[i];
        i++;
    }
    i++;
    char off[32]={0};
    for(int j=0;i+j<len;j++)
    {
        off[j]=arg_cd[i+j];
    }
    offset=atol(off);
    return offset;
}

int makedir(MYSQL* conn,char *dir,int code,int uid)
{
    int t;
    MYSQL_RES *res;
    MYSQL_ROW row;
    int new_code;
    char op[64]={0};
    char result[128]={0};
    char query[256]="SELECT MAX(code) FROM dir WHERE uid=";
    sprintf(query,"%s%d",query,uid);
    t=mysql_query(conn,query);
    if(t)
    {
        sprintf(op,"%s %s","makedir",dir);
        sprintf(result,"Error making query,precode=%d",code);
        log_mysql(conn,op,uid,result);
        return -1;
    }
    else
    {
        res=mysql_store_result(conn);
        if(res)
        {
            while((row=mysql_fetch_row(res))!=NULL)
            {
                new_code=atoi(row[0])+1;
                //插入新的目录
                char query_init[60]="INSERT INTO dir(precode,code,uid,filename,filetype) values";
                sprintf(query_init,"%s(%d,%d,%d,'%s','%s')",query_init,code,new_code,uid,dir,"d");
                int r=mysql_query(conn,query_init);
                if(r)
                {
                    sprintf(op,"%s %s","makedir",dir);
                    sprintf(result,"Error making query,precode=%d",code);
                    log_mysql(conn,op,uid,result);
                    return -1;
                }
            }
        }
        mysql_free_result(res);
        sprintf(op,"%s %s","makedir",dir);
        sprintf(result,"%s,precode=%d","success",code);
        log_mysql(conn,op,uid,result);
    }
    return 1;
}

int cd(MYSQL*conn,char* dir,int* code,int uid)
{
    char op[64]={0};
    char result[128]={0};
    if(!(*code)&&!strcmp(dir,".."))    //根目录不能再往上
    {
        sprintf(op,"%s %s","cd",dir);
        sprintf(result,"%s,code=%d","Root can not cd .. ",*code);
        log_mysql(conn,op,uid,result);
        return -1;
    }
    int t;
    MYSQL_RES *res;
    MYSQL_ROW row;
    if(!strcmp(dir,".."))
    {
        //向上一级
        char query[256]="SELECT precode FROM dir WHERE uid=";
        sprintf(query,"%s%d AND code=%d",query,uid,*code);
        t=mysql_query(conn,query);
        if(t)
        {
            sprintf(op,"%s %s","cd",dir);
            sprintf(result,"Error making query,code=%d",*code);
            log_mysql(conn,op,uid,result);
            return -1;
        }
        else
        {
            res=mysql_store_result(conn);
            if(res)
            {
                while((row=mysql_fetch_row(res))!=NULL)
                {
                    //把code改变
                    *code=atoi(row[0]);
                }
            }
            mysql_free_result(res);
            sprintf(op,"%s %s","cd",dir);
            sprintf(result,"%s","success");
            log_mysql(conn,op,uid,result);
            return 2;
        }
    }
    else
    {
        //判断是否当前目录下有该目录
        char query[128]="SELECT code FROM dir WHERE uid=";
        sprintf(query,"%s%d AND filename='%s'",query,uid,dir);
        t=mysql_query(conn,query);
        if(t)
        {
            sprintf(op,"%s %s","cd",dir);
            sprintf(result,"Error making query,precode=%d",*code);
            log_mysql(conn,op,uid,result);
            return -1;
        }
        else
        {
            res=mysql_store_result(conn);
            if(res)
            {
                while((row=mysql_fetch_row(res))!=NULL)
                {
                    if(row[0]==NULL)
                    {
                        //没有这个目录
                        sprintf(op,"%s %s","cd",dir);
                        sprintf(result,"%s","failed,no such dir");
                        log_mysql(conn,op,uid,result);
                        return -1;
                    }
                    else
                    {
                        sprintf(op,"%s %s","cd",dir);
                        sprintf(result,"%s","success");
                        log_mysql(conn,op,uid,result);
                        *code=atoi(row[0]);
                        return 3;
                    }
                }
            }
        }
    }
    return 0;
}

int ls(MYSQL*conn,int code,int uid,char* usrname,int sfd)
{
    char op[64]={0};
    char result[128]={0};
    int t;
    train ls;
    MYSQL_RES *res;
    MYSQL_ROW row;
    int ret;
    char query[128]="SELECT filetype,size,time,filename FROM dir WHERE";
    sprintf(query,"%s uid=%d AND precode=%d",query,uid,code);
    t=mysql_query(conn,query);
    if(t)
    {
        sprintf(op,"%s","ls");
        sprintf(result,"Error making query,code=%d",code);
        log_mysql(conn,op,uid,result);
        return -1;
    }
    else
    {
        res=mysql_store_result(conn);
        if(res)
        {
            int row_num=mysql_num_rows(res);
            if(row_num>0)
            {
                ret=4;
                send(sfd,&ret,sizeof(ret),0);   //发送结果给客户端
                send(sfd,&row_num,sizeof(row_num),0);   //发送ls的行数
                while((row=mysql_fetch_row(res))!=NULL)
                {
                    bzero(ls.buf,sizeof(ls.buf));
                    sprintf(ls.buf,"\t%s  %s\t%10ld\t%s\t%s\n",row[0],usrname,atol(row[1]),row[2],row[3]);
                    ls.len=strlen(ls.buf);
                    send_n(sfd,(char*)&ls,4+ls.len);
                }
            }
            else
            {
                ret=-1;
                send(sfd,&ret,sizeof(ret),0);   //发送结果给客户端
            }
        }
        mysql_free_result(res);
        sprintf(op,"%s","ls");
        sprintf(result,"%s","success");
        log_mysql(conn,op,uid,result);
    }
    return ret;
}
//客户端从服务器下载文件
int gets_cd(int mode,MYSQL*conn,char *arg_cd,int code,int uid,int sfd)
{
    char op[64]={0};
    char result[128]={0};
    int t;
    int ret=0;
    MYSQL_RES *res;
    MYSQL_ROW row;
    off_t offset=0;
    int row_num=0;
    char file_name[64]={0};
    char md5[33]={0};
    if(mode==8)
    {
        offset=get_offset(file_name,arg_cd);
    }
    else if(mode==5)
    {
        strcpy(file_name,arg_cd);
    }
    char query[128]="SELECT md5 FROM dir WHERE";
    sprintf(query,"%s uid=%d AND filename='%s' AND precode=%d",query,uid,file_name,code);
    t=mysql_query(conn,query);
    if(t)
    {
        sprintf(op,"%s %s","gets",arg_cd);
        sprintf(result,"Error making query,precode=%d",code);
        log_mysql(conn,op,uid,result);
        ret=-1;
    }
    else
    {
        res=mysql_store_result(conn);
        row_num=mysql_num_rows(res);
        if((row=mysql_fetch_row(res))!=NULL)
            strcpy(md5,row[0]);
        mysql_free_result(res);
        //要传输的文件存在于当前目录下
        if(row_num>0)
        {
            ret=7;
            send_n(sfd,(char*)&ret,sizeof(ret));   //通知客户端接受文件

            ret=send_file(sfd,md5,offset);
            if(ret==-1)
            {
                sprintf(op,"%s %s","gets",arg_cd);
                sprintf(result,"%s","send failed");
                log_mysql(conn,op,uid,result);
                goto end;
            }
            sprintf(op,"%s %s","gets",arg_cd);
            sprintf(result,"send success,offset=%ld",offset);
            log_mysql(conn,op,uid,result);
        }
        else
        {
            ret=-1;
            send_n(sfd,(char*)&ret,sizeof(ret));
            sprintf(op,"%s %s","gets",arg_cd);
            sprintf(result,"%s","send failed,no such file");
            log_mysql(conn,op,uid,result);
        }
    }
end:
    return ret;
}
//客户端上传文件
int puts_cd(MYSQL*conn,int code,int uid,int sfd)
{
    char op[64]={0};
    char result[128]={0};
    int len;
    int ret=0;
    int row_num=-1;
    char md5[40]={0};
    char file_name[32]={0};
    off_t file_size=0;
    MYSQL_RES* res;

    //接文件md5码,客户端计算md5需要时间
    //需要循环，防止发送还没到达就被读取,导致读取失败
    while(1)
    {
        if(recv_n(sfd,(char*)&len,4)==0)
        {
            recv_n(sfd,md5,len);
            break;
        }
    }

    //检查是否网盘上已经存在该文件，匹配md5
    int t;
    char query[256]="SELECT * FROM dir WHERE";
    sprintf(query,"%s md5='%s'",query,md5);
    t=mysql_query(conn,query);
    if(t)
    {
        sprintf(op,"%s","puts");
        sprintf(result,"Error making query,precode=%d",code);
        log_mysql(conn,op,uid,result);
        ret=-1;
    }
    else
    {
        res=mysql_store_result(conn);
        row_num=mysql_num_rows(res);
        mysql_free_result(res);
        if(row_num==0)                   //不存在该文件
        {
            ret=8;
            send_n(sfd,(char*)&ret,sizeof(ret));   //通知客户端开始发送文件

            ret=recv_file(sfd,file_name,&file_size,md5);

            if(ret>=0)
            {
                //在数据库中插入文件
                bzero(query,sizeof(query));
                strcpy(query,"INSERT INTO dir(precode,uid,filename,filetype,size,md5) VALUES");
                sprintf(query,"%s(%d,%d,'%s','-',%ld,'%s')",query,code,uid,file_name,file_size,md5);
                t=mysql_query(conn,query);
                if(t)
                {
                    sprintf(op,"%s %s","puts",file_name);
                    sprintf(result,"Error making query,precode=%d",code);
                    log_mysql(conn,op,uid,result);
                    ret=-1;
                }
                else
                {
                    sprintf(op,"%s %s","puts",file_name);
                    sprintf(result,"%s,precode=%d","success",code);
                    log_mysql(conn,op,uid,result);
                }
            }

        }
        //如果文件已经存在
        else
        {
            ret=-1;
            send_n(sfd,(char*)&ret,sizeof(ret));
            sprintf(op,"%s","puts");
            sprintf(result,"%s","File already exists");
            log_mysql(conn,op,uid,result);
        }
    }
    return ret;
}

int rm(MYSQL*conn,char *file_name,int code,int uid)
{
    char op[64]={0};
    char result[128]={0};
    int t;
    MYSQL_RES* res;
    int row_num=-1;
    char query[128]="SELECT * FROM dir WHERE filename=";
    sprintf(query,"%s'%s' AND uid=%d AND precode=%d AND filetype='-'",query,file_name,uid,code);
    t=mysql_query(conn,query);
    if(t)
    {
        sprintf(op,"%s %s","remove",file_name);
        sprintf(result,"Error making query,precode=%d",code);
        log_mysql(conn,op,uid,result);
        return -1;
    }
    else
    {
        res=mysql_store_result(conn);
        row_num=mysql_num_rows(res);
        mysql_free_result(res);
        if(row_num==0)                   //不存在该文件
        {
            sprintf(op,"%s %s","remove",file_name);
            sprintf(result,"No such file,precode=%d",code);
            log_mysql(conn,op,uid,result);
            return -1;
        }
        else if(row_num>0)          //如果存在该文件
        {
            bzero(query,sizeof(query));
            strcpy(query,"DELETE FROM dir WHERE filename=");
            sprintf(query,"%s'%s' AND uid=%d AND precode=%d AND filetype='-'",query,file_name,uid,code);
            t=mysql_query(conn,query);
            if(t)
            {
                sprintf(op,"%s %s","remove",file_name);
                sprintf(result,"Error making query,precode=%d",code);
                log_mysql(conn,op,uid,result);
                return -1;
            }
            else
            {
                remove(file_name);
                sprintf(op,"%s %s","remove",file_name);
                sprintf(result,"%s","success");
                log_mysql(conn,op,uid,result);
                return 6;
            }
        }
    }
    return 0;
}

int excute_Command(MYSQL* conn,int sfd,int command_id,char * arg_cd,int* code,int uid,char* usrname)
{
    int ret;
    switch (command_id) {
    case 1:
        ret=makedir(conn,arg_cd,*code,uid);
        send(sfd,&ret,sizeof(ret),0);   //发送结果给客户端
        break;
    case 2:
        ret=cd(conn,arg_cd,code,uid);  //2代表返回上一级，3进入arg_cd指定的目录
        send(sfd,&ret,sizeof(ret),0);   //发送结果给客户端
        break;
    case 3:
        ls(conn,*code,uid,usrname,sfd);
        break;
    case 4:
        //puts
        puts_cd(conn,*code,uid,sfd);
        break;
    case 5:
        //gets
        gets_cd(command_id,conn,arg_cd,*code,uid,sfd);
        break;
    case 6:
        //remove
        ret=rm(conn,arg_cd,*code,uid);
        send(sfd,&ret,sizeof(ret),0);
        break;
    case 7:
        //pwd
        ret=5;
        send(sfd,&ret,sizeof(ret),0);
        break;
    case 8:
        //断点续传
        gets_cd(command_id,conn,arg_cd,*code,uid,sfd);
        break;
    default:
        break;
    }
    return 0;
}
