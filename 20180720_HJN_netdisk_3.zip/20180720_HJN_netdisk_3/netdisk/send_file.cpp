#include"func.h"

void signal_handle(int signum)
{
    printf("%d signal is coming\n",signum);
}

int send_file(int new_fd,const char* file_name,off_t offset)
{
    signal(SIGPIPE,signal_handle);

    train file;
    int ret;
    int fd;


    //send file size
    fd=open(file_name,O_RDONLY);
    lseek(fd,offset,SEEK_SET);
    check_error(-1,fd,"open");
    struct stat buf;
    fstat(fd,&buf);
    buf.st_size-=offset;
    file.len=sizeof(buf.st_size);
    memcpy(file.buf,&buf.st_size,sizeof(off_t));
    ret=send_n(new_fd,(char*)&file,4+file.len);
    if(-1==ret)
        goto end;

    //如果大于100M,mmap
    if(buf.st_size>=100000000)
    {
        int len=buf.st_size;
        int total=0;
        while(total<len)
        {
            ret=sendfile(new_fd,fd,NULL,len-total);
            if(-1==ret)
            {
                if(errno==EAGAIN)
                {
                    continue;
                }
                else
                    goto end;
            }
            total+=ret;
        }
    }
    else
    {
        //send content
        while((file.len=read(fd,file.buf,sizeof(file.buf)))>0)
        {
            ret=send_n(new_fd,(char*)&file,4+file.len);
            if(-1==ret)
                goto end;
        }

        ret=send_n(new_fd,(char*)&file,4+file.len);
        if(-1==ret)
            goto end;
    }

end:
    close(fd);
    return ret;
}
