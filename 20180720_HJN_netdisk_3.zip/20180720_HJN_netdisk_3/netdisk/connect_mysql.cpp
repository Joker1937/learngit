#include"func.h"

int connect_mysql(MYSQL* conn)
{
    FILE* mysql_config_file;
    mysql_config_file=fopen("mysql_config","rb");
    check_error(NULL,mysql_config_file,"fopen");
    char server[16]={0};
    char usr[10]={0};
    char password[20]={0};
    fscanf(mysql_config_file,"%s%s%s",server,usr,password);

    char* database="netdisk";   //要访问的数据库名称
    char query[400]="CREATE TABLE dir(precode int NOT NULL,code int,md5 varchar(32),\
                    uid int NOT NULL,filename varchar(50),\
                    filetype varchar(5),PRIMARY KEY(uid,filetype,filename),\
                    time TIMESTAMP,size bigint default 0,\
                    constraint uid_FK foreign key(uid) references usr(uid))";
    int t;
    int init=0;     //init>0,则dir表已经存在
    if(!mysql_real_connect(conn,server,usr,password,database,0,NULL,0))
    {
        printf("Error connecting to database:%s\n",mysql_error(conn));
        return -1;
    }else
    {
        printf("Database connected...\n");
    }
    init=mysql_query(conn,query);

    //为md5建立索引
    bzero(query,sizeof(query));
    strcpy(query,"CREATE INDEX dir_md5 ON dir(md5)");
    t=mysql_query(conn,query);

    //从usr表中读取所有的用户uid
    //表不存在时，才向dir表格中插入各用户的根目录
    if(!init)
    {
        MYSQL_RES *res;
        MYSQL_ROW row;
        bzero(query,sizeof(query));
        strcpy(query,"select uid from usr");
        t=mysql_query(conn,query);
        if(t)
        {
            printf("Error making query:%s\n",mysql_error(conn));
            return -1;
        }
        else
        {
            res=mysql_store_result(conn);
            if(res)
            {
                while((row=mysql_fetch_row(res))!=NULL)
                {
                    for(t=0;t<mysql_num_fields(res);t++)
                    {
                        char query_init[128]="INSERT INTO dir(precode,code,uid,filename,filetype) values(-1,0,";
                        sprintf(query_init,"%s%s,'%s','%s')",query_init,row[t],"/","d");
                        int r=mysql_query(conn,query_init);
                        if(r)
                        {
                            printf("Error making query:%s\n",mysql_error(conn));
                            return -1;
                        }
                    }
                }
                mysql_free_result(res);
            }
        }
    }

    //建立log表
    bzero(query,sizeof(query));
    strcpy(query,"CREATE TABLE log(id INT NOT NULL AUTO_INCREMENT,PRIMARY KEY(id),\
            uid INT NOT NULL,operation VARCHAR(64) NOT NULL,\
            time TIMESTAMP,result VARCHAR(128) NOT NULL)");
    init=mysql_query(conn,query);
    //为操作内容建立索引
    if(!init)
    {
        bzero(query,sizeof(query));
        strcpy(query,"CREATE INDEX log_op ON log(operation)");
        mysql_query(conn,query);
    }
    return 0;
}

int get_Salt(MYSQL *conn,char *usrname,char *salt)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    int uid=0;
    char query[50]="select salt,uid from usr where uname=";
    sprintf(query,"%s'%s'",query,usrname);

    int t;
    t=mysql_query(conn,query);
    if(t)
    {
        printf("Error making query:%s\n",mysql_error(conn));
        return -1;
    }
    else
    {
        res=mysql_use_result(conn);
        if(res)
        {
            while((row=mysql_fetch_row(res))!=NULL)
            {
                if(mysql_num_fields(res)==2)
                {
                    strcpy(salt,row[0]);
                    uid=atoi(row[1]);
                }
            }
            mysql_free_result(res);
        }
    }
    return uid;
}

int get_Pwdp(MYSQL *conn,char *usrname,char *pwdp)
{
    MYSQL_RES *res;
    MYSQL_ROW row;
    char query[50]="select password from usr where uname=";
    sprintf(query,"%s'%s'",query,usrname);

    int t;
    t=mysql_query(conn,query);
    if(t)
    {
        printf("Error making query:%s\n",mysql_error(conn));
        return -1;
    }
    else
    {
        res=mysql_use_result(conn);
        if(res)
        {
            while((row=mysql_fetch_row(res))!=NULL)
            {
                for(t=0;t<mysql_num_fields(res);t++)
                {
                    strcpy(pwdp,row[t]);
                }
            }
            mysql_free_result(res);
        }
    }

    return 0;
}

int log_mysql(MYSQL* conn,const char* op,int uid,char* result)
{
    //插入操作内容
    char query[128]="INSERT INTO log(uid,operation,result) VALUES";
    sprintf(query,"%s(%d,'%s','%s')",query,uid,op,result);
    int t=mysql_query(conn,query);
    if(t)
    {
        printf("Error making query:%s\n",mysql_error(conn));
        return -1;
    }
    return 0;
}
