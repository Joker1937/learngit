#include"func.h"

//Initialize structure variables
int f_init(pfac pf,thread_func_t threadfunc,int thread_num,int capacity)
{
    bzero(pf,sizeof(factory));
    pf->pth_id=(pthread_t*)calloc(thread_num,sizeof(pthread_t));
    pf->threadfunc=threadfunc;
    pthread_cond_init(&pf->cond,NULL);
    pthread_mutex_init(&pf->que.que_mutex,NULL);
    pf->pthread_num=thread_num;
    pf->que.que_capacity=capacity;
    return 0;
}

//create all child threads
int f_start(pfac pf)
{
    if(!pf->start_flag)
    {
        for(int i=0;i<pf->pthread_num;i++)
        {
            pthread_create(pf->pth_id+i,NULL,pf->threadfunc,pf);
        }
        pf->start_flag=1;
    }
    return 0;
}

//Initialization of the tcp connection, returning the server-bound sfd
int tcp_init(const char*ip,int port,int client_num)
{
    int init_sfd=socket(AF_INET,SOCK_STREAM,0);
    int reuse=1;
    setsockopt(init_sfd,SOL_SOCKET ,SO_REUSEADDR,(const char*)&reuse,sizeof(int));
    check_error(-1,init_sfd,"socket");
    struct sockaddr_in serveraddr;
    memset(&serveraddr,0,sizeof(struct sockaddr));
    serveraddr.sin_family=AF_INET;
    serveraddr.sin_port=htons(port);
    serveraddr.sin_addr.s_addr=inet_addr(ip);
    int ret=bind(init_sfd,(struct sockaddr*)&serveraddr,sizeof(struct sockaddr));
    check_error(-1,ret,"bind");
    ret=listen(init_sfd,client_num);
    check_error(-1,ret,"listen");
    return init_sfd;
}
