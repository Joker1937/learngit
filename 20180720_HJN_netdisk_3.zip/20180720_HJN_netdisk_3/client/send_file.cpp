#include"func.h"

void signal_handle(int signum)
{
    printf("%d signal is coming\n",signum);
}

int send_file(int new_fd,const char* file_name)
{
    signal(SIGPIPE,signal_handle);

    train file;
    int ret;
    int fd;

    //send file name
    bzero(&file,sizeof(file));
    file.len=strlen(file_name);
    strcpy(file.buf,file_name);
    ret=send_n(new_fd,(char*)&file,4+file.len);
    if(-1==ret)
        goto end;


    //send file size
    fd=open(file_name,O_RDONLY);
    if(fd==-1)
    {
        perror("open");
        return -1;
    }
    struct stat buf;
    fstat(fd,&buf);
    file.len=sizeof(buf.st_size);
    memcpy(file.buf,&buf.st_size,sizeof(off_t));
    ret=send_n(new_fd,(char*)&file,4+file.len);
    if(-1==ret)
        goto end;
    //如果大于100M,mmap
    if(buf.st_size>=100000000)
    {
        ret=sendfile(new_fd,fd,NULL,buf.st_size);
        if(-1==ret)
            goto end;
    }
    else
    {
        //send content
        while((file.len=read(fd,file.buf,sizeof(file.buf)))>0)
        {
            ret=send_n(new_fd,(char*)&file,4+file.len);
            if(-1==ret)
                goto end;
        }
        ret=send_n(new_fd,(char*)&file,4+file.len);
        if(-1==ret)
            goto end;
    }

end:
    close(fd);
    return ret;
}
