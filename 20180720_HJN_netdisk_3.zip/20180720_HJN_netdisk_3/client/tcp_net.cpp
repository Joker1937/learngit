#include"tcp_net_socket.h"


int tcp_init(const char*ip,int port,int pro_num)
{
        int init_sfd=socket(AF_INET,SOCK_STREAM,0);
        check_error(-1,init_sfd,"socket");
        struct sockaddr_in serveraddr;
        memset(&serveraddr,0,sizeof(struct sockaddr));
        serveraddr.sin_family=AF_INET;
        serveraddr.sin_port=htons(port);
        serveraddr.sin_addr.s_addr=inet_addr(ip);
        int ret=bind(init_sfd,(struct sockaddr*)&serveraddr,sizeof(struct sockaddr));
        check_error(-1,ret,"bind");
        ret=listen(init_sfd,pro_num);
        check_error(-1,ret,"listen");
        return init_sfd;
}

int tcp_accept(int sfd)
{
        struct sockaddr_in clientaddr;
        socklen_t addrlen=sizeof(struct sockaddr);
        memset(&clientaddr,0,addrlen);
        int new_sfd=accept(sfd,(struct sockaddr*)&clientaddr,&addrlen);
        check_error(-1,new_sfd,"accept");
        printf("ip=%s, prot=%d success connect....\n",inet_ntoa(clientaddr.sin_addr),ntohs(clientaddr.sin_port));
        return new_sfd;
}

int tcp_connect(const char*ip,int port)
{
        int sfd=socket(AF_INET,SOCK_STREAM,0);
        check_error(-1,sfd,"socket");
        struct sockaddr_in serveraddr;
        memset(&serveraddr,0,sizeof(struct sockaddr));
        serveraddr.sin_family=AF_INET;
        serveraddr.sin_port=htons(port);
        serveraddr.sin_addr.s_addr=inet_addr(ip);
        int ret=connect(sfd,(struct sockaddr*)&serveraddr,sizeof(struct sockaddr));
        check_error(-1,ret,"connect");
        return sfd;
}
