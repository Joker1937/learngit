#include"func.h"

int login(int sfd)
{
    int epfd=epoll_create(1);
    struct epoll_event event,evs[1];
    event.events=EPOLLIN;
    event.data.fd=sfd;
    int ret=epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
    check_error(-1,ret,"epoll_ctl");

    int iret;
    char *pwdp;
    char salt[16]={0};
    int flag=0;
    char usr_name[16]={0};
    char password[16]={0};

    //输入用户名，发送给服务器
    printf("user name :");
    //scanf("%s",usr_name);
    strcpy(usr_name,"test"); //for test
    send(sfd,usr_name,strlen(usr_name),0);

    //获取用户名对应的salt
    while(1)
    {
        bzero(salt,sizeof(salt));
        iret=recv(sfd,salt,sizeof(salt)-1,0);
        if(iret>0)
        {
            if(strcmp(salt,"fail")==0)
            {
                printf("No such user\n");
                goto end;
            }
            goto next;
        }
        else if(0==iret)
        {
            event.data.fd=sfd;
            epoll_ctl(epfd,EPOLL_CTL_DEL,sfd,&event);
            close(sfd);
            printf("bye\n");
            exit(0);
        }
        else
        {
            printf("\n");
            close(sfd);
            exit(1);
        }
    }
next:
    //输入密码
    printf("password:");
    //scanf("%s",password);
    strcpy(password,"123");  //for test
    //得到密文，发送给服务器进行匹配
    pwdp=crypt(password,salt);
    send(sfd,pwdp,strlen(pwdp),0);

    //查询是否登录成功
    while(1)
    {
        ret=epoll_wait(epfd,evs,1,-1);
        for(int i=0;i<ret;i++)
        {
            if(evs[i].data.fd==sfd)
            {
                while(1)
                {
                    iret=recv(sfd,&flag,sizeof(flag),0);
                    if(iret>0)
                    {
                        if(flag==1)
                            printf("登录成功\n");
                        else
                        {
                            printf("登录失败\n");
                            exit(2);
                        }
                        goto end;
                    }
                    else if(0==iret)
                    {
                        event.data.fd=sfd;
                        epoll_ctl(epfd,EPOLL_CTL_DEL,sfd,&event);
                        close(sfd);
                        printf("bye\n");
                        exit(0);
                    }
                    else
                    {
                        printf("\n");
                        close(sfd);
                        exit(1);
                    }
                }
            }
        }
    }
end:
    return 0;
}
