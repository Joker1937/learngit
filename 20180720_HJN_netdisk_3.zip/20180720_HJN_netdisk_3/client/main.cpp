#include"func.h"

int main()
{
    char ip[16]={0};
    int port;

    //for test
    strcpy(ip,"192.168.5.54");
    port=2000;
    printf("Please input the ip:");
    //scanf("%s",ip);
    printf("now,input the port:");
    //scanf("%d",&port);

    //初始化socket
    int sfd=socket(AF_INET,SOCK_STREAM,0);
    check_error(-1,sfd,"socket");
    struct sockaddr_in ser;
    bzero(&ser,sizeof(ser));
    ser.sin_family=AF_INET;
    ser.sin_port=htons(port);//端口号转换为网络字节序
    ser.sin_addr.s_addr=inet_addr(ip);//点分10进制的IP地址转为网络字节序
    int ret=connect(sfd,(struct sockaddr*)&ser,sizeof(struct sockaddr));
    check_error(-1,ret,"connect");

    //登录
    login(sfd);

    //IO复用监听事件
    int epfd=epoll_create(1);
    struct epoll_event event,evs[2];
    event.events=EPOLLIN;
    event.data.fd=STDIN_FILENO;
    ret=epoll_ctl(epfd,EPOLL_CTL_ADD,STDIN_FILENO,&event);
    check_error(-1,ret,"epoll_ctl");
    event.data.fd=sfd;
    ret=epoll_ctl(epfd,EPOLL_CTL_ADD,sfd,&event);
    check_error(-1,ret,"epoll_ctl1");

    //协议中的变量
    char buf[128]={0};
    int recv_flag=0;
    int iret;
    char path[64]={0};
    char ls_ret[128]={0};
    int len;    //ls的行数
    int ls_ret_len; //每行的长度
    char file_name[128]={0};
    char md5[33]={0};
    int command_id;
    int is_exists=0;
    train file;
    command_st command;
    bzero(&file,sizeof(file));
    strcpy(path,"/");
    printf("%s$: ",path);
    fflush(stdout);
    while(1)
    {
        ret=epoll_wait(epfd,evs,2,-1);
        for(int i=0;i<ret;i++)
        {
            if(evs[i].data.fd==sfd)
            {
                //接受命令返回结果
                iret=recv(sfd,&recv_flag,sizeof(recv_flag),0);
                if(iret>0&&recv_flag>0)
                {
                    switch (recv_flag) {
                    case -1:
                        printf("Failed!\n");
                        break;
                    //makedir
                    case 1:
                        printf("makedir success\n");
                        break;
                    //cd
                    case 2:
                    case 3:
                        if(command_id==2)
                            change_path(path,recv_flag,file_name);
                        break;
                    //ls
                    case 4:
                        recv(sfd,&len,sizeof(len),0);
                        for(int j=0;j<len;j++)
                        {
                            recv(sfd,&ls_ret_len,sizeof(ls_ret_len),0);
                            bzero(ls_ret,sizeof(ls_ret));
                            recv(sfd,ls_ret,ls_ret_len,0);
                            printf("%s",ls_ret);
                            fflush(stdout);
                        }
                        break;
                    //pwd
                    case 5:
                        printf("%s\n",path);
                        break;
                    //remove
                    case 6:
                        printf("remove success\n");
                        break;
                    //gets
                    case 7:
                        printf("recv file...\n");
                        iret=recv_file(sfd,file_name,is_exists);
                        if(iret==0)
                        {
                            printf("recv file success\n");
                        }
                        else
                        {
                            printf("recv file failed\n");
                            goto end;
                        }
                        break;
                    case 8:
                        printf("send file...\n");
                        iret=send_file(sfd,file_name);
                        if(iret==-1)
                        {
                            printf("send file failed\n");
                            goto end;
                        }
                        printf("send success\n");
                        break;
                    default:
                        break;
                    }
                }
                printf("%s$: ",path);
                fflush(stdout);
            }
            if(EPOLLIN==evs[i].events&&evs[i].data.fd==STDIN_FILENO)
            {
                //客户端给出命令，发送给服务器
                bzero(buf,sizeof(buf));
                read(STDIN_FILENO,buf,sizeof(buf));
                //判断命令合法性
                bzero(file_name,sizeof(file_name));
                command_id=get_command(buf,file_name);
                if(command_id<0)
                {
                    printf("%s$: ",path);
                    fflush(stdout);
                    continue;
                }
                else
                {
                    bzero(&command,sizeof(command));
                    command.command_id=command_id;
                    strcpy(command.buf,file_name);
                    if(command.command_id==5)   //gets
                    {
                        is_exists=gets_file(file_name);  //是否存在文件
                        if(is_exists)    //存在
                        {
                            sprintf(command.buf,"%s %ld",command.buf,is_exists);
                            command.command_id=8;
                        }
                    }
                    if(command.command_id==4)       //puts
                    {
                        iret=get_md5(file_name,md5);
                        if(iret<0)
                        {
                            printf("%s$: ",path);
                            fflush(stdout);
                            continue;
                        }
                        command.len=strlen(command.buf);
                        send_n(sfd,(char*)&command,8+command.len);

                        //send md5
                        file.len=strlen(md5);
                        strcpy(file.buf,md5);
                        send_n(sfd,(char*)&file,4+file.len);
                        continue;
                    }
                    command.len=strlen(command.buf);
                    send_n(sfd,(char*)&command,8+command.len);
                }
            }
        }
    }
end:
    close(sfd);
    return 0;
}
