#ifndef _TCP_NET_SOCKET_H
#define _TCP_NET_SOCKET_H

#include"head.h"

int tcp_init(const char*,int,int);
int tcp_accept(int);
int tcp_connect(const char*,int);

#endif
