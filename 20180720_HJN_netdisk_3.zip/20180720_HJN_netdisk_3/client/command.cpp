#include"func.h"

char command[COMMAND_NUM][8]={"makedir","cd","ls","puts","gets","remove","pwd"};
//判断命令是否是需要响应的那些,返回命令编号
int judge_Precd(char *precd)
{
    int i;
    for(i=0;i<COMMAND_NUM;i++)
    {
        if(!strcmp(precd,command[i]))
            return i+1;
    }
    return 0;                  //没有匹配的命令
}

int get_command(char* command,char *last_cd)
{
    int len=strlen(command)-1;
    char pre_cd[7]={0};         //shell命令名
    char arg_cd[121]={0};
    int i=0;
    int pre_cd_get=0;           //是否读取完成shell命令名

    //忽略开头的空格
    while(i<len&&command[i]==' ')
    {
        i++;
    }
    //将command前部分shell命令读入
    int precd_len=0;
    for(;precd_len<8&&i<len;i++)
    {
        if(command[i]!=' ')
        {
            pre_cd[precd_len++]=command[i];
        }
        else
        {
            pre_cd_get=1;
            break;
        }
    }
    if(!strcmp(pre_cd,"ls")||!strcmp(pre_cd,"pwd"))
    {
        pre_cd_get=1;
    }
    int judge_ret=judge_Precd(pre_cd);
    //无效命令
    if(!pre_cd_get||!judge_ret)
        return -1;

    //忽略shell命令和命令操作对象之间的空格
    while(i<len&&command[i]==' ')
    {
        i++;
    }
    //读入操作对象
    for(int k=0;k<len-i;k++)
    {
        if(command[i+k]==' ')
            break;
        arg_cd[k]=command[i+k];
    }

    if(last_cd)
    {
        strcpy(last_cd,arg_cd);
    }
    return judge_ret;
}

void change_path(char *path,int arg,char* dir)
{
    int len=strlen(path);
    int i=len-1;
    switch (arg) {
    case 2:
        //改变path
        while(i>=0)
        {
            if(path[i]=='/')
                break;
            i--;
        }
        for(;i<len;i++)
        {
            path[i]='\0';
        }
        if(strlen(path)==0)
            strcpy(path,"/");
        break;
    case 3:
        if(strcmp(path,"/")==0)
            sprintf(path,"%s%s",path,dir);
        else
            sprintf(path,"%s/%s",path,dir);
        break;
    default:
        break;
    }
}
