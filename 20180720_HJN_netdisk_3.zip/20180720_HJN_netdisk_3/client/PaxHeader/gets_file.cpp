58 path=20180720_华建楠_netdisk_3/client/gets_file.cpp
27 mtime=1531985241.946892
27 atime=1532068626.379312
