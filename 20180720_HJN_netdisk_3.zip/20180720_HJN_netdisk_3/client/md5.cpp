#include"func.h"

int get_md5(const char *filename, char *md5_str)
{
    int fd;
    int ret=0;
    int i=0;
    unsigned char   data[READ_MAX_SIZE];
    unsigned char   md5_value[MD5_SIZE];
    MD5_CTX         md5;

    if ((fd = open(filename, O_RDONLY)) < 0)
    {
        perror("open failed");
        return -1;
    }
    MD5_Init(&md5);

    while(1)
    {
        ret = read(fd, data, READ_MAX_SIZE);
        if (ret == -1)
        {
            perror("read failed");
            close(fd);
            return -1;
        }
        MD5_Update(&md5, data, ret);
        if (ret == 0 || ret < READ_MAX_SIZE)
        {
            close(fd);
            break;
        }

    }
    MD5_Final((unsigned char *)&md5_value, &md5);
    for(i = 0; i < MD5_SIZE;i++)
    {
        snprintf(md5_str + i * 2, 2 + 1, "%02x", md5_value[i]);
    }
    md5_str[MD5_STR_LEN] = '\0';
    return 0;
}
