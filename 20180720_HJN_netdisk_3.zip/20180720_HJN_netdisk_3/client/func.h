#ifndef FUNC_H
#define FUNC_H

#include"head.h"
#include"tcp_net_socket.h"

#define COMMAND_NUM 7
#define     READ_MAX_SIZE   1024
#define     MD5_SIZE        16
#define     MD5_STR_LEN     (MD5_SIZE * 2)
#define BUF_SIZE 1024
#define PAGE_SIZE 4096

//发送文件内容时的结构体
typedef struct{
    int len;
    char buf[BUF_SIZE];
}train;


//命令
typedef struct
{
    int len;
    int command_id;
    char buf[128];
}command_st;

off_t gets_file(char* file_name);
void change_path(char *path,int arg,char* dir);
int get_command(char* command,char *last_cd);
int send_n(int,char*,int);
int recv_n(int,char*,int);
int send_file(int,const char*);
int recv_file(int sfd,const char* file_name,int);
int get_md5(const char *filename, char *md5_str);

int login(int);

#endif // FUNC_H
