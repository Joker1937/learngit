#include"func.h"

off_t gets_file(char* file_name)
{
    off_t ret=0;

    int fd=open(file_name,O_RDONLY);
    if(fd>0)        //文件存在
    {
        struct stat buf;
        fstat(fd,&buf);
        ret=buf.st_size;
    }
    close(fd);

    return ret;
}
